import string,re
from email_bot import *

import imaplib, email, os, base64, traceback, random, textract, codecs
from email.header import decode_header


def percent(founded_str,txt):
    count_indexes = 0
    for i in founded_str:
        count_indexes += len(i)
    percent = 100 * (count_indexes/len(txt))
    return  percent

def get_sp(input_index_start, txt):
    string = []
    str = ''
    # removed minuss element '-' from not_necessary_str
    not_necessary_str = ['\t', '\n', '\r', '\x0b', '\x0c', '!', '"', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~']
    for i in txt[input_index_start:]:
        if i == ' ':
            break
        else:
            string.append(i)
    return ''.join(string)

def search_(input, txt):
    input = input.lower()
    if len(input) > 0:
        all_matches = re.finditer(pattern = f"{input}", string = txt.lower())
        founded_str = []        
        for match in all_matches:
            finded_percent = (100 * (len(input)/len(get_sp(match.start(),txt))))
            if finded_percent >= 50:
                founded_str.append(get_sp(match.start(),txt))
        return percent(founded_str,txt),founded_str
    else:
        return('Write a word !')


# def login_email(email,password):
#     connect = imaplib.IMAP4_SSL('imap.gmail.com')
#     return connect

def extracting_not_necessary_str(text):
    not_necessary_str = ['\t', '\n', '\r', '\x0b', '\x0c', '!', '"', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~']
    text = ''.join([ch for ch in text if ch not in not_necessary_str ])
    return text

# 
def count(data):
    type_of_files = {
        'pdf':0,
        'docx':0,
        'xls':0,
        'other_files':0
    }
    
    for file_name in data:
        for i in file_name:
            x = i.split('.')[-1]
            if x == 'pdf':
                type_of_files['pdf'] += 1
            elif x == 'docx':
                type_of_files['docs'] += 1
            elif x == 'xls':
                type_of_files['xls'] += 1
            else:
                type_of_files['other_files'] += 1
    return type_of_files

def get_stat_str(a):
    text = '<b>📊 Statistics (by email content type)</b>\n\n'
    for i in a:
        text += f'{i[0].capitalize()} = {i[1]},\n' 
    return text
