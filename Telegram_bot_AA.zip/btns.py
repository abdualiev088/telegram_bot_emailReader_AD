from aiogram.types import ReplyKeyboardRemove, \
    ReplyKeyboardMarkup, KeyboardButton, \
    InlineKeyboardMarkup, InlineKeyboardButton

search = KeyboardButton('🔍 Search')
logout = KeyboardButton('⬅️ Logout')
login = KeyboardButton('🚪 Login')
stat = KeyboardButton('📊 Statistics')


whileLogIn = ReplyKeyboardMarkup(resize_keyboard=True)
whileLogIn.add(logout,search,stat)

whileStart = ReplyKeyboardMarkup(resize_keyboard=True)
whileStart.add(login)