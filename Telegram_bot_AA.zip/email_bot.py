from func import *
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram import Bot, Dispatcher, types, filters
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher import FSMContext
from aiogram.utils import executor
import sqlite3,imaplib, email, logging, asyncio
from btns import *

import string,re
import imaplib, email, os, base64, traceback, random, textract, codecs
from email.header import decode_header

def get_email(mail):
    all_files = []
    mail.select()
    answer = ''

    type, data = mail.search(None, 'ALL')
    mail_ids = data[0]
    id_list = mail_ids.split()
    for num in data[0].split():
        typ, data = mail.fetch(num, '(RFC822)')
        raw_email = data[0][1]
        # converts byte literal to string removing b''
        raw_email_string = raw_email.decode('utf-8')
        email_message = email.message_from_string(raw_email_string)
        # downloading attachments
        for part in email_message.walk():
            # this part comes from the snipped I don't understand yet... 
            if part.get_content_maintype() == 'multipart':
                continue
            if part.get('Content-Disposition') is None:
                continue

            fileName, encoding = decode_header(part.get_filename())[0]
            if isinstance(fileName, bytes):
                fileName = fileName.decode(encoding)
            
            if bool(fileName):
                filePath = os.path.join('../download/', fileName)
                if not os.path.isfile(filePath) :
                    fp = open(filePath, 'wb')
                    fp.write(part.get_payload(decode=True))
                    fp.close()
                    all_files.append([fileName, filePath])
                subject = str(email_message).split("Subject: ", 1)[1].split("\nTo:", 1)[0]
                # print('Downloaded "{file}" from email titled "{subject}".'.format(file=fileName, subject=subject))  
    return all_files

def read_file(file_path):
    text = []
    textract_text = textract.process(file_path)
    textract_str_text = codecs.decode(textract_text)
    for i in textract_str_text:
        text.append(i)
    return ''.join(text)

def create_database():
    cursor.execute("""
	CREATE TABLE IF NOT EXISTS email_docs(
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name CHARACTER,
		hole_content CHARACTER 
	)""")
    connect.commit()
    return connect

def insert_into_database(file_name, hole_content):
    cursor.execute("INSERT INTO email_docs(name, hole_content) VALUES(?, ?)", (file_name, hole_content)) 
    connect.commit()
    return 'Done'

connect_1 = sqlite3.connect('username.db')
cursor_1 = connect_1.cursor()

connect = sqlite3.connect('email_docs.db')
cursor = connect.cursor()

def ifEmail(imap):
    lists = get_email(imap)[0]
    
    create_database()
    for i in lists:
        file_name, file_path = i
        hole_content = read_file(file_path)
        sqlite_select_query = 'SELECT name FROM email_docs WHERE name = "{}"'.format(file_name)
        cursor.execute(sqlite_select_query)
        record = cursor.fetchone()
        if not record:
            return insert_into_database(file_name, hole_content)
        elif record[0] != file_name: 
            return insert_into_database(file_name, hole_content)


# getting email and password from DATABSE
# try:
#     cursor_1.execute(f"SELECT * from username;")
#     data = cursor_1.fetchone()
#     email_db = data[2]
#     password_db = data[3]

#     if data:
#         imap = imaplib.IMAP4_SSL('imap.gmail.com')
#         imap.login(email_db, password_db)
cursor_1.execute(f"SELECT * from username;")
data = cursor_1.fetchone()
if data:
    email_db = data[2]
    password_db = data[3]
    imap = imaplib.IMAP4_SSL('imap.gmail.com')
    imap.login(email_db, password_db)
    # ifEmail(imap)
# except:
#     print('You didn\'t register yet')

logging.basicConfig(level=logging.INFO)

KEY_API = '5233217036:AAGZ5bccSihk2yLmY2NSECS5YN7FOeA9XlI'
bot = Bot(token=KEY_API, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot, storage = MemoryStorage())

@dp.message_handler(Command('start'))
async def whenStart1(message: types.Message):
    cursor_1.execute(f"SELECT * from username;")
    data = cursor_1.fetchone()

    if data:
        await message.answer(f'👋 Hi @{message.from_user.username}\n\n', reply_markup=whileLogIn)
    else:
        await message.answer(f'👋 Hi @{message.from_user.username}\n\nClick <b>🚪 Login</b> button to connect email.', reply_markup=whileStart)
    
class login(StatesGroup):
    email = State()
    password = State()

@dp.message_handler(Text('🚪 Login'))
async def register(message: types.Message):
    cursor_1.execute(f"SELECT * from username;")
    data = cursor_1.fetchone()
    if not data:
        await message.answer('<b>Step: 1/2</b>\n\n📧 Write your email')
        await login.email.set()
    else:
        await message.answer(f'😁 You already logged in ', reply_markup=whileLogIn)

@dp.message_handler(state=login.email)
async def state_1(message: types.Message, state: FSMContext):
    answer = message.text

    await state.update_data(email=answer)
    await message.answer('<b>Step: 2/2</b>\n\n🔐 Write your password')
    await login.password.set()

@dp.message_handler(state=login.password)
async def state_2(message: types.Message, state: FSMContext):
    answer = message.text

    await state.update_data(password=answer)

    data = await state.get_data()
    email = data.get('email')
    password = data.get('password')

    await state.finish()

    try:
        # create database
        user_chat_id = message.chat.id
        username = message.from_user.username
        cursor_1.execute("""CREATE TABLE IF NOT EXISTS username(user_chat_id INTEGER,username CHARACTER,email CHARACTER,password CHARACTER)""")
        connect_1.commit() 

        cursor_1.execute(f"SELECT * from username;")
        data = cursor_1.fetchone()

        email_db = ''
        password_db = ''

        imap = imaplib.IMAP4_SSL('imap.gmail.com')

        
        if data is None:
        # add values in fields
            cursor_1.execute("INSERT INTO username(user_chat_id, username, email, password) VALUES(?, ?, ?, ?);", (user_chat_id, username, email, password))
            connect_1.commit()
            
        else:
            email_db = data[2]
            password_db = data[3]
            imap.login(email_db, password_db)

        await message.answer('✅ You Successfully loged in', reply_markup=whileLogIn)
        
    except Exception as e:
        await message.answer('⭕ Something went wrong', reply_markup=whileStart)
        print(e)

class search(StatesGroup):
    word = State()

@dp.message_handler(Text('🔍 Search'))
async def register(message: types.Message):
    cursor_1.execute(f"SELECT * from username;")
    data = cursor_1.fetchone()
    if data:
        await message.answer('🔍 Write to search')
        await search.word.set()
    else:
        await message.answer(f'🥺 Please log in', reply_markup=whileStart)
    

@dp.message_handler(state=search.word)
async def state_s_1(message: types.Message, state: FSMContext):
    answer = message.text
    await state.update_data(word=answer)
    await state.finish()
    cursor.execute(f"SELECT * from email_docs;")
    data = cursor.fetchall()
    str = []

    for i in data:
        hole_txt = i[2].lower()
        if answer.lower() in hole_txt:
            str.append(f'Found at: {i[1]}, <b>{search_(answer,i[2])}</b>\n')
        
    if not str:
        await message.answer('no matches', reply_markup=whileLogIn)
    else:
        await message.answer(''.join(str), reply_markup=whileLogIn)
        
@dp.message_handler(text='⬅️ Logout')
async def Logout(message: types.Message):
    sqlite_select_query = 'SELECT * from email_docs'
    cursor.execute(sqlite_select_query)
    data = cursor.fetchone()

    if data:
        # delete user from database
        sql = 'DELETE FROM username'
        cursor_1.execute(sql)
        connect_1.commit()
        await message.answer('💤 You log out', reply_markup=whileStart)
    else:
        await message.answer('👉 Sign in', reply_markup=whileStart)
    
@dp.message_handler(text='📊 Statistics')
async def Stat(message: types.Message):
    cursor_1.execute(f"SELECT * from username;")
    data = cursor_1.fetchone()
    if data:
        cursor.execute(f"SELECT name from email_docs")
        data = cursor.fetchall()
        a = sorted(count(data).items(), key=lambda x: x[1], reverse=True)
        await message.answer(get_stat_str(a))
    else:
        await message.answer(f'🥺 Please log in', reply_markup=whileStart)
    

if __name__ == "__main__":
	executor.start_polling(dp, skip_updates=True)